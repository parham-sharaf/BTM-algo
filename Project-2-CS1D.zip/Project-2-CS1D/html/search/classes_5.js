var searchData=
[
  ['mainwindow_23',['MainWindow',['../classMainWindow.html',1,'']]],
  ['manage_5fteams_24',['manage_teams',['../classmanage__teams.html',1,'']]]
];
