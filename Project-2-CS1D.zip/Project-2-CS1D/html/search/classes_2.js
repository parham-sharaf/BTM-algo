var searchData=
[
  ['db_16',['db',['../classdb.html',1,'']]],
  ['display_5fpurchases_17',['display_purchases',['../classdisplay__purchases.html',1,'']]],
  ['display_5fteam_18',['display_team',['../classdisplay__team.html',1,'']]],
  ['distance_19',['Distance',['../structDistance.html',1,'']]]
];
