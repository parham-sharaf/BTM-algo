var searchData=
[
  ['mainwindow_9',['MainWindow',['../classMainWindow.html',1,'']]],
  ['manage_5fteams_10',['manage_teams',['../classmanage__teams.html',1,'']]]
];
