var searchData=
[
  ['purchase_5fsouvenirs_25',['purchase_souvenirs',['../classpurchase__souvenirs.html',1,'']]]
];
