var searchData=
[
  ['admin_0',['admin',['../classadmin.html',1,'']]]
];
