#ifndef DB_H
#define DB_H


class db
{
public:
    db();

};

#endif // DB_H
